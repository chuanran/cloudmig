npm-whoami(3) -- Display npm username
=====================================

## SYNOPSIS

    npm.commands.whoami(args, callback)

## DESCRIPTION

Print the `username` config to standard output.

'args' is never used and callback is never called with data.
'args' must be present or things will break.

This function is not useful programmatically
