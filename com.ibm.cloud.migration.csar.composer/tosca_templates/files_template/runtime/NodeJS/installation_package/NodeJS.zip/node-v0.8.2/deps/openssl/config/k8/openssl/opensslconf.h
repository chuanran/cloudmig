#ifdef WIN32
#include "opensslconf-win32.h"
#else
#include "opensslconf-posix.h"
#endif
